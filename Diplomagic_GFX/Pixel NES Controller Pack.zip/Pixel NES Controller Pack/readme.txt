Hi there :)

Thank you for using this asset! If you have any feedback or ideas for improvements, or if you need new assets for your game, feel free to send me a message. I’d be happy to add it to the roadmap.

Happy game developing!
Dead Revolver